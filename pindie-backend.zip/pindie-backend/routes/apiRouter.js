const apiRouter = require("express").Router();
const gamesRouter = require("./games");
const usersRouter = require("./users")
const categoriesRouter = require ("./categories")
const authRouter = require ("./main")
apiRouter.use("/api", gamesRouter);
// Импорты и инициализация главного роута
apiRouter.use("/api", gamesRouter);
apiRouter.use("/api", usersRouter);
apiRouter.use("/api", categoriesRouter);
apiRouter.use("/api", authRouter);
// Код роута
module.exports = {apiRouter};